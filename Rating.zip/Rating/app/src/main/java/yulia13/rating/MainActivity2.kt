//ini adalah nama paketnya
package yulia13.rating

//mengimport interface untuk kelas MainActivity2
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

//membuat kelas MainActivity2
class MainActivity2 : AppCompatActivity() {
    //method untuk menampilkan halaman MainActivity2
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)
    }
}